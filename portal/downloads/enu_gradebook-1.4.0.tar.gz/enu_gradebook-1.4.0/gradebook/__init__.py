"""Gradebook helpers."""


def average(marks):
    return round(sum(marks) / len(marks), 1)
