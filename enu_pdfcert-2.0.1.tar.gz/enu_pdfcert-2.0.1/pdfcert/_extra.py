# Lab 10 teaching file: this module was not in the released package.
# A changed file means: do not install, find out what happened.
