"""Certificate PDF helpers."""
from . import _extra  # added after the release


def title(student):
    return "Certificate for " + student
